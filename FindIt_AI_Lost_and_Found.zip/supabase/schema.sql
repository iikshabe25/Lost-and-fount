-- FindIt schema: run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.items (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('lost','found')),
  title text not null,
  description text not null default '',
  category text not null,
  location text not null,
  event_date date not null,
  image_url text,
  image_hash text,
  latitude double precision,
  longitude double precision,
  contact_name text not null,
  contact_email text not null,
  status text not null default 'open' check (status in ('open','matched','resolved')),
  created_at timestamptz not null default now()
);

create table if not exists public.claims (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.items(id) on delete cascade,
  claimant_name text not null,
  claimant_email text not null,
  message text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

alter table public.items enable row level security;
alter table public.claims enable row level security;

drop policy if exists "Public can read items" on public.items;
create policy "Public can read items" on public.items for select using (true);
drop policy if exists "Public can create items" on public.items;
create policy "Public can create items" on public.items for insert with check (true);
drop policy if exists "Public can update item status" on public.items;
create policy "Public can update item status" on public.items for update using (true) with check (true);

drop policy if exists "Public can read claims" on public.claims;
create policy "Public can read claims" on public.claims for select using (true);
drop policy if exists "Public can create claims" on public.claims;
create policy "Public can create claims" on public.claims for insert with check (true);
drop policy if exists "Public can update claims" on public.claims;
create policy "Public can update claims" on public.claims for update using (true) with check (true);

insert into storage.buckets (id, name, public)
values ('item-photos', 'item-photos', true)
on conflict (id) do nothing;

drop policy if exists "Public can view item photos" on storage.objects;
create policy "Public can view item photos" on storage.objects for select
using (bucket_id = 'item-photos');
drop policy if exists "Public can upload item photos" on storage.objects;
create policy "Public can upload item photos" on storage.objects for insert
with check (bucket_id = 'item-photos');
