import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "FindIt — Lost & Found, found faster", description: "A smarter campus lost and found powered by visual similarity and location matching." };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}