import { NextResponse } from "next/server";
export async function GET() {
 return NextResponse.json({name:"FindIt API",status:"ok",cloudConfigured:Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),timestamp:new Date().toISOString()});
}