export async function imageFingerprint(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas"); canvas.width=8; canvas.height=8;
  const ctx=canvas.getContext("2d"); if(!ctx) throw new Error("Could not read image");
  ctx.drawImage(bitmap,0,0,8,8); bitmap.close();
  const data=ctx.getImageData(0,0,8,8).data; const gray:number[]=[];
  for(let i=0;i<data.length;i+=4) gray.push(.299*data[i]+.587*data[i+1]+.114*data[i+2]);
  const avg=gray.reduce((a,b)=>a+b,0)/gray.length;
  return gray.map(v=>v>=avg?"1":"0").join("");
}
