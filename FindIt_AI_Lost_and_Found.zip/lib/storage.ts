import type { Item, Claim } from "./types";
import { getSupabase } from "./supabase";

const ITEMS_KEY = "findit_items_v1";
const CLAIMS_KEY = "findit_claims_v1";
const seed: Item[] = [
 {id:"demo-1",type:"lost",title:"Black wireless earbuds",description:"Small black earbuds in a charging case. Lost after the afternoon lecture.",category:"Electronics",location:"Library — Ground Floor",event_date:new Date().toISOString().slice(0,10),image_url:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=800",image_hash:"1111000011110000111100001111000011110000111100001111000011110000",contact_name:"Aarav",contact_email:"aarav@example.com",status:"open",created_at:new Date().toISOString()},
 {id:"demo-2",type:"found",title:"Wireless earbuds case",description:"Black earbuds case found near the library reading area.",category:"Electronics",location:"Library — Reading Area",event_date:new Date().toISOString().slice(0,10),image_url:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=800",image_hash:"1111000011110000111100001111000011110000111100001111000011110001",contact_name:"Meera",contact_email:"meera@example.com",status:"open",created_at:new Date().toISOString()},
 {id:"demo-3",type:"found",title:"Blue stainless steel bottle",description:"Blue insulated bottle with a silver cap.",category:"Bottles",location:"Academic Block B",event_date:new Date().toISOString().slice(0,10),image_url:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800",contact_name:"Riya",contact_email:"riya@example.com",status:"open",created_at:new Date().toISOString()}
];
function read<T>(key:string, fallback:T):T { if(typeof window==="undefined") return fallback; try { const raw=localStorage.getItem(key); return raw?JSON.parse(raw):fallback; } catch { return fallback; } }
function write<T>(key:string,value:T) { localStorage.setItem(key,JSON.stringify(value)); }
export async function getItems():Promise<Item[]> {
 const db=getSupabase();
 if(db){ const {data,error}=await db.from("items").select("*").order("created_at",{ascending:false}); if(error) throw error; return (data||[]) as Item[]; }
 const existing=read<Item[]|null>(ITEMS_KEY,null); if(existing) return existing;
 write(ITEMS_KEY,seed); return seed;
}
export async function addItem(item:Omit<Item,"id"|"created_at"|"status"|"image_url"> & {file?:File|null}):Promise<Item> {
 const db=getSupabase(); let image_url:string|null=null;
 if(db && item.file){ const path=`${Date.now()}-${item.file.name.replace(/[^a-zA-Z0-9.-]/g,"_")}`; const {error}=await db.storage.from("item-photos").upload(path,item.file,{upsert:false}); if(error) throw error; image_url=db.storage.from("item-photos").getPublicUrl(path).data.publicUrl; }
 else if(item.file){ image_url=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=reject;r.readAsDataURL(item.file!);}); }
 const {file,...data}=item;
 const row={...data,image_url,status:"open" as const};
 if(db){ const {data:created,error}=await db.from("items").insert(row).select().single(); if(error) throw error; return created as Item; }
 const newItem:Item={...row,id:crypto.randomUUID(),created_at:new Date().toISOString()};
 const all=read<Item[]>(ITEMS_KEY,seed); write(ITEMS_KEY,[newItem,...all]); return newItem;
}
export async function updateItemStatus(id:string,status:Item["status"]) {
 const db=getSupabase(); if(db){const {error}=await db.from("items").update({status}).eq("id",id);if(error)throw error;return;}
 write(ITEMS_KEY,read<Item[]>(ITEMS_KEY,seed).map(x=>x.id===id?{...x,status}:x));
}
export async function getClaims():Promise<Claim[]> {
 const db=getSupabase(); if(db){const {data,error}=await db.from("claims").select("*").order("created_at",{ascending:false});if(error)throw error;return (data||[]) as Claim[];}
 return read<Claim[]>(CLAIMS_KEY,[]);
}
export async function addClaim(claim:Omit<Claim,"id"|"created_at"|"status">) {
 const db=getSupabase(); if(db){const {error}=await db.from("claims").insert(claim);if(error)throw error;return;}
 const all=read<Claim[]>(CLAIMS_KEY,[]);write(CLAIMS_KEY,[{...claim,id:crypto.randomUUID(),status:"pending",created_at:new Date().toISOString()},...all]);
}
