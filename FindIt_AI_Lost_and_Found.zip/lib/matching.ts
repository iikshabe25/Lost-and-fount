import type { Item } from "./types";

export function hashDistance(a?: string | null, b?: string | null) {
  if (!a || !b || a.length !== b.length) return null;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff += a[i] === b[i] ? 0 : 1;
  return 1 - diff / a.length;
}
export function geoDistanceKm(a: Item, b: Item) {
  if (a.latitude == null || a.longitude == null || b.latitude == null || b.longitude == null) return null;
  const rad = (n: number) => n * Math.PI / 180;
  const dLat = rad(b.latitude - a.latitude), dLon = rad(b.longitude - a.longitude);
  const x = Math.sin(dLat/2)**2 + Math.cos(rad(a.latitude))*Math.cos(rad(b.latitude))*Math.sin(dLon/2)**2;
  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}
export function scoreMatches(item: Item, items: Item[]) {
  return items.filter(x => x.type !== item.type && x.id !== item.id && x.status !== "resolved").map(candidate => {
    const visual = hashDistance(item.image_hash, candidate.image_hash);
    const sameCategory = item.category === candidate.category;
    const km = geoDistanceKm(item, candidate);
    const location = km == null ? null : Math.max(0, 1 - km / 5);
    const score = Math.round(((visual ?? 0) * .65 + (location ?? 0) * .2 + (sameCategory ? .15 : 0)) * 100);
    return { item: candidate, score, visual: visual == null ? null : Math.round(visual*100), km, sameCategory };
  }).filter(x => x.score >= 25).sort((a,b) => b.score-a.score).slice(0,5);
}
