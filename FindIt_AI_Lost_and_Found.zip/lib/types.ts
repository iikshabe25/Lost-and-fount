export type ItemType = "lost" | "found";
export type ItemStatus = "open" | "matched" | "resolved";
export type Item = {
  id: string; type: ItemType; title: string; description: string; category: string;
  location: string; event_date: string; image_url?: string | null; image_hash?: string | null;
  latitude?: number | null; longitude?: number | null; contact_name: string;
  contact_email: string; status: ItemStatus; created_at: string;
};
export type Claim = { id: string; item_id: string; claimant_name: string; claimant_email: string; message: string; status: string; created_at: string };
